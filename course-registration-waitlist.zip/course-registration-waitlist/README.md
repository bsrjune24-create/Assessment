# Course Registration – Enrollment and FIFO Waitlist

A bounded .NET 8 Web API prototype for one course offering (`dotnet-101`). It implements enrollment, dropping, prerequisite checks, and FIFO waitlist promotion. It intentionally does not implement a frontend, catalog, payments, identity integration, or persistent database.

## Prerequisite and waitlist assumptions

- `IPrerequisiteChecker` is the authoritative prerequisite boundary. The demo implementation reads eligible learner IDs from `appsettings.json`; replace it with the starter project's prerequisite source when integrating.
- A learner must satisfy the prerequisite both when requesting enrollment and when considered for promotion.
- A learner can appear at most once across enrolled and waitlisted state (case-insensitive learner ID comparison).
- When full, an eligible learner is appended to the waitlist.
- During promotion, entries are considered in ascending insertion sequence. The earliest currently eligible learner is promoted.
- An ineligible entry at the head is skipped but retained in its original queue position. Later eligible entries may be promoted. The retained entry is reconsidered on a later promotion attempt.
- Dropping a waitlisted learner is outside this slice; DELETE applies only to enrolled learners.
- The demo uses a fixed offering ID and capacity of two.

## Run

Requires the .NET 8 SDK.

```bash
dotnet restore CourseRegistration.sln
dotnet test CourseRegistration.sln
dotnet run --project src/CourseRegistration.Api
```

The API listens on the local URL printed by ASP.NET Core (commonly `http://localhost:5000` or `https://localhost:7000`).

## API examples

Read state:

```bash
curl http://localhost:5000/api/offerings/dotnet-101
```

Enroll:

```bash
curl -X POST http://localhost:5000/api/offerings/dotnet-101/enrollments \
  -H "Content-Type: application/json" \
  -d '{"learnerId":"learner-1"}'
```

Drop:

```bash
curl -X DELETE http://localhost:5000/api/offerings/dotnet-101/enrollments/learner-1
```

Demo eligible IDs are `learner-1` through `learner-5`. Change `Course:EligibleLearnerIds` in `appsettings.json` for local exploration.

## Design and verification

See:
- `docs/DESIGN-SPECIFICATION.md`
- `docs/AI-USE-RECORD.md`
- `docs/VERIFICATION.md`
- `docs/LIMITATIONS.md`

The automated tests cover available capacity, full capacity, duplicate requests, FIFO promotion, prerequisite failure, ineligible-head skipping/retention, invalid and repeated drops, and concurrent enrollment. The in-memory lock is process-local; it is not sufficient for multiple API instances.
