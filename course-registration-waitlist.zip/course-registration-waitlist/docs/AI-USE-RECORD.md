# AI Prompt and Use Record

This record is intentionally candid: AI assistance was used to propose a bounded design and test checklist. The implementation must still be reviewed and executed locally before submission.

## Activity 1 – Design decomposition

**Prompt used**

> Design a minimal .NET service for one course offering that supports enrollment, drop, prerequisite validation, and FIFO waitlist promotion. State invariants, concurrency concerns, and a consistent policy for ineligible waitlisted learners. Keep the scope limited and propose focused tests.

**AI response summary**

- Separate the HTTP controller, application service, prerequisite checker, and store.
- Enforce one learner record across enrolled and waitlisted state.
- Serialize enrollment and drop-plus-promotion as atomic operations.
- Consider waitlist entries in insertion order and explicitly define how ineligible entries are handled.
- Test capacity, duplicate requests, prerequisites, FIFO promotion, invalid drops, and concurrency.

**Decision:** Accepted with edits. The implementation uses a private process-local lock and chooses the skip-but-retain policy for ineligible waitlist entries. The design explicitly calls out that a database transaction/locking mechanism is required for multi-instance production deployments.

**Files/decisions informed:** `EnrollmentService.cs`, `IPrerequisiteChecker.cs`, `DESIGN-SPECIFICATION.md`.

## Activity 2 – Test planning

**Prompt used**

> Create a focused xUnit test matrix for enrollment and waitlist behavior, including an ineligible learner at the front of the queue and concurrent enrollment. Avoid testing unrelated registration-platform features.

**AI response summary**

- Test successful enrollment with available capacity.
- Fill capacity and assert an eligible learner is waitlisted.
- Retry an enrolled/waitlisted learner and assert no duplicate.
- Drop an enrolled learner and assert earliest eligible waitlisted learner is promoted.
- Test prerequisite failure and invalid/repeated drops.
- Run concurrent enrollments and assert capacity and uniqueness invariants.

**Decision:** Accepted, then adapted to the chosen skip-but-retain policy. Added a test that changes a learner's eligibility after waitlisting so the head is skipped while the next eligible learner is promoted.

**Files informed:** `EnrollmentServiceTests.cs`.

## Independent review and verification status

The code and tests are intended as the deliverable, but AI-generated suggestions are not treated as proof of correctness. Run the commands in `README.md` and record the actual output in `VERIFICATION.md`. Review the lock scope, case-insensitive duplicate checks, and waitlist scan against the invariants before submission.

No credentials, secrets, or personal data were included in prompts.
