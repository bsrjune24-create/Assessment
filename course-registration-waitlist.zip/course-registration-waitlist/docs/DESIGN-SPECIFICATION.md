# Design Specification

## Scope and service boundary

The `IEnrollmentService` is the application boundary for one offering. The controller maps HTTP requests to service operations and translates result codes to HTTP status codes. The service owns all state transitions. `IPrerequisiteChecker` isolates prerequisite evaluation from registration logic.

## Data/API design

- Offering: fixed ID `dotnet-101`, capacity `2`.
- Enrolled: ordered list of learner IDs.
- Waitlist: entries with learner ID and monotonically increasing sequence.
- `POST /api/offerings/dotnet-101/enrollments` with `{ "learnerId": "..." }`.
- `DELETE /api/offerings/dotnet-101/enrollments/{learnerId}`.
- `GET /api/offerings/dotnet-101` returns capacity, counts, enrolled IDs, and waitlist order.

## Invariants

1. `0 <= Enrolled.Count <= Capacity`.
2. A learner ID occurs at most once across enrolled and waitlisted collections.
3. Only prerequisite-eligible learners may be enrolled or newly waitlisted.
4. A promotion moves exactly one eligible waitlisted learner to enrolled; if none is eligible, the seat remains open.
5. Invalid requests and unsuccessful drops do not mutate state.

## Enrollment flow

Validate non-empty learner ID; normalize surrounding whitespace; under the service lock reject a learner already enrolled/waitlisted; evaluate prerequisite; enroll if a seat exists; otherwise append a waitlist entry with the next sequence.

## Drop and promotion flow

Validate learner ID and locate the enrolled record under the same lock. If absent, return `NotEnrolled` without mutation. Remove the learner, then scan waitlist entries in sequence order. Skip but retain currently ineligible entries. Remove and enroll the first eligible entry. If no eligible entry exists, leave the seat available.

## Concurrency and persistence

A private `lock` serializes validation and all state changes in this single-process prototype, including drop plus promotion. This prevents two concurrent requests from exceeding capacity within one API process. The store is in memory, so state is lost on restart. For multi-instance or durable operation, use a database transaction with appropriate row/unique constraints and lock the offering/queue rows (or an equivalent atomic claim mechanism). Preserve the starter project's established transaction strategy if integrating into an existing system.

## Tradeoffs

- One offering and one fixed capacity keep the slice bounded.
- Demo prerequisites are configured IDs, not a production learner/course model.
- Waitlist sequence is represented in memory; persistent storage would need a durable ordering key.
- Retaining ineligible entries preserves their queue position and allows later re-eligibility; it can leave stale entries in the queue indefinitely.
