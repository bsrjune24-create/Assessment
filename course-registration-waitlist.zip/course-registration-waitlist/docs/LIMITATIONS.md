# Limitations and Follow-up Risks

- The store is in memory; data is lost on process restart.
- `lock` protects only a single process. Multiple API instances require database transactions or distributed coordination.
- The demo prerequisite checker uses a configured allow-list. Production integration should call the authoritative prerequisite source and define its freshness/consistency expectations.
- A skipped ineligible waitlist entry remains queued. If it never becomes eligible, it may remain indefinitely; operational cleanup is outside this scope.
- No waitlist cancellation endpoint is included because the requested slice specifies dropping enrolled learners only.
- The offering ID and capacity are fixed for this one-offering prototype.
- API integration tests and persistence tests are not included; the focused service-level tests exercise the state transitions directly.
