# Verification Evidence

## Automated test command

```bash
dotnet restore CourseRegistration.sln
dotnet test CourseRegistration.sln --configuration Release
```

## Test coverage intended

| Scenario | Test |
|---|---|
| Available capacity | `Enrolls_when_capacity_is_available` |
| Full capacity | `Adds_eligible_learner_to_waitlist_when_full` |
| Duplicate enrollment | `Duplicate_enrollment_does_not_create_duplicate_records` |
| FIFO promotion | `Drop_promotes_earliest_eligible_waitlisted_learner_fifo` |
| Prerequisite failure | `Prerequisite_failure_does_not_change_state` |
| Ineligible head policy | `Ineligible_front_entry_is_skipped_and_retained` |
| Invalid/repeated drops | `Invalid_and_repeated_drops_do_not_corrupt_state` |
| Concurrent enrollment | `Concurrent_enrollment_never_exceeds_capacity_or_duplicates` |

## Execution record

This project was generated in an environment where the .NET SDK execution result was not available. Therefore no passing test result is claimed here. Run the commands above on a machine with the .NET 8 SDK and replace this note with the actual build/test output before submission.
