using CourseRegistration.Api.Models;
using CourseRegistration.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace CourseRegistration.Api.Controllers;

[ApiController]
[Route("api/offerings/dotnet-101")]
public sealed class OfferingsController(IEnrollmentService enrollmentService) : ControllerBase
{
    [HttpGet]
    public ActionResult<OfferingSnapshot> Get() => Ok(enrollmentService.GetSnapshot());

    [HttpPost("enrollments")]
    public ActionResult<OperationResult> Enroll([FromBody] EnrollRequest request)
    {
        var result = enrollmentService.Enroll(request.LearnerId);
        return result.Code switch
        {
            "Enrolled" => Ok(result),
            "Waitlisted" => Ok(result),
            "InvalidRequest" => BadRequest(result),
            "PrerequisiteFailed" => Conflict(result),
            "Duplicate" => Conflict(result),
            _ => StatusCode(500, result)
        };
    }

    [HttpDelete("enrollments/{learnerId}")]
    public ActionResult<OperationResult> Drop(string learnerId)
    {
        var result = enrollmentService.Drop(learnerId);
        return result.Code switch
        {
            "Dropped" => Ok(result),
            "InvalidRequest" => BadRequest(result),
            "NotEnrolled" => NotFound(result),
            _ => StatusCode(500, result)
        };
    }
}
