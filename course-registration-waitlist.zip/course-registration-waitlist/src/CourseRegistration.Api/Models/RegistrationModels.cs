namespace CourseRegistration.Api.Models;

public sealed record EnrollRequest(string? LearnerId);

public sealed record OperationResult(
    string Code,
    string Message,
    string? LearnerId = null,
    string? PromotedLearnerId = null);

public sealed record OfferingSnapshot(
    string OfferingId,
    int Capacity,
    int EnrolledCount,
    int AvailableSeats,
    IReadOnlyList<string> EnrolledLearners,
    IReadOnlyList<string> WaitlistedLearners);
