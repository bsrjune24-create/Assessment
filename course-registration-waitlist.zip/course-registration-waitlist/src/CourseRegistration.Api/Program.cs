using CourseRegistration.Api.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddSingleton<InMemoryCourseStore>();
builder.Services.AddSingleton<IPrerequisiteChecker>(_ =>
{
    var eligible = builder.Configuration.GetSection("Course:EligibleLearnerIds").Get<string[]>()
                   ?? Array.Empty<string>();
    return new InMemoryPrerequisiteChecker(eligible);
});
builder.Services.AddSingleton<IEnrollmentService, EnrollmentService>();

var app = builder.Build();
app.MapControllers();
app.MapGet("/", () => Results.Ok(new
{
    service = "Course Registration API",
    offeringId = "dotnet-101",
    endpoints = new[] { "GET /api/offerings/dotnet-101",
                        "POST /api/offerings/dotnet-101/enrollments",
                        "DELETE /api/offerings/dotnet-101/enrollments/{learnerId}" }
}));
app.Run();
