using CourseRegistration.Api.Models;

namespace CourseRegistration.Api.Services;

/// <summary>
/// Atomic application-service boundary for one course offering.
/// The lock protects validation, enrollment/waitlist mutation, and promotion
/// as one critical section. This is process-local, not a distributed lock.
/// </summary>
public sealed class EnrollmentService(
    InMemoryCourseStore store,
    IPrerequisiteChecker prerequisiteChecker) : IEnrollmentService
{
    private readonly object _gate = new();

    public OperationResult Enroll(string? learnerId)
    {
        if (string.IsNullOrWhiteSpace(learnerId))
            return new("InvalidRequest", "LearnerId is required.");

        learnerId = learnerId.Trim();

        lock (_gate)
        {
            if (ContainsLearner(learnerId))
                return new("Duplicate", "Learner is already enrolled or waitlisted.", learnerId);

            if (!prerequisiteChecker.IsEligible(learnerId))
                return new("PrerequisiteFailed", "Learner does not satisfy the prerequisite.", learnerId);

            if (store.Enrolled.Count < store.Capacity)
            {
                store.Enrolled.Add(learnerId);
                return new("Enrolled", "Enrollment completed.", learnerId);
            }

            store.Waitlist.Add(new WaitlistEntry(learnerId, store.NextSequence++));
            return new("Waitlisted", "Course is full; learner added to the waitlist.", learnerId);
        }
    }

    public OperationResult Drop(string? learnerId)
    {
        if (string.IsNullOrWhiteSpace(learnerId))
            return new("InvalidRequest", "LearnerId is required.");

        learnerId = learnerId.Trim();

        lock (_gate)
        {
            var enrolledIndex = store.Enrolled.FindIndex(
                id => string.Equals(id, learnerId, StringComparison.OrdinalIgnoreCase));

            if (enrolledIndex < 0)
                return new("NotEnrolled", "Learner is not currently enrolled.", learnerId);

            store.Enrolled.RemoveAt(enrolledIndex);
            var promoted = PromoteEarliestEligible();

            return new("Dropped", "Enrollment dropped.",
                learnerId, promoted);
        }
    }

    public OfferingSnapshot GetSnapshot()
    {
        lock (_gate)
        {
            return new OfferingSnapshot(
                store.OfferingId,
                store.Capacity,
                store.Enrolled.Count,
                store.Capacity - store.Enrolled.Count,
                store.Enrolled.ToArray(),
                store.Waitlist.OrderBy(x => x.Sequence).Select(x => x.LearnerId).ToArray());
        }
    }

    private bool ContainsLearner(string learnerId) =>
        store.Enrolled.Any(id => string.Equals(id, learnerId, StringComparison.OrdinalIgnoreCase)) ||
        store.Waitlist.Any(x => string.Equals(x.LearnerId, learnerId, StringComparison.OrdinalIgnoreCase));

    private string? PromoteEarliestEligible()
    {
        // Ineligible entries are skipped but retained in their original FIFO position.
        // The first eligible entry is removed and promoted.
        foreach (var entry in store.Waitlist.OrderBy(x => x.Sequence).ToArray())
        {
            if (!prerequisiteChecker.IsEligible(entry.LearnerId))
                continue;

            store.Waitlist.Remove(entry);
            store.Enrolled.Add(entry.LearnerId);
            return entry.LearnerId;
        }

        return null;
    }
}
