using CourseRegistration.Api.Models;

namespace CourseRegistration.Api.Services;

public interface IEnrollmentService
{
    OperationResult Enroll(string? learnerId);
    OperationResult Drop(string? learnerId);
    OfferingSnapshot GetSnapshot();
}
