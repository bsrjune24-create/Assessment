namespace CourseRegistration.Api.Services;

public interface IPrerequisiteChecker
{
    bool IsEligible(string learnerId);
}

/// <summary>
/// Demo prerequisite source. Replace with the starter project's authoritative
/// prerequisite lookup if one exists. IDs in appsettings.json are eligible.
/// </summary>
public sealed class InMemoryPrerequisiteChecker(IEnumerable<string> eligibleLearnerIds)
    : IPrerequisiteChecker
{
    private readonly HashSet<string> _eligible =
        new(eligibleLearnerIds, StringComparer.OrdinalIgnoreCase);

    public bool IsEligible(string learnerId) => _eligible.Contains(learnerId);
}
