namespace CourseRegistration.Api.Services;

/// <summary>
/// Single-process store for the one-offering assessment prototype.
/// All access is serialized by EnrollmentService's private lock.
/// </summary>
public sealed class InMemoryCourseStore(int capacity = 2)
{
    public string OfferingId { get; } = "dotnet-101";
    public int Capacity { get; } = capacity;

    public List<string> Enrolled { get; } = new();
    public List<WaitlistEntry> Waitlist { get; } = new();
    public long NextSequence { get; set; } = 1;
}

public sealed record WaitlistEntry(string LearnerId, long Sequence);
