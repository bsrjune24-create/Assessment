using CourseRegistration.Api.Services;
using Xunit;

namespace CourseRegistration.Tests;

public sealed class EnrollmentServiceTests
{
    private static (EnrollmentService Service, MutablePrerequisites Rules) Create(int capacity = 2)
    {
        var store = new InMemoryCourseStore(capacity);
        var rules = new MutablePrerequisites("a", "b", "c", "d", "e", "f");
        return (new EnrollmentService(store, rules), rules);
    }

    [Fact]
    public void Enrolls_when_capacity_is_available()
    {
        var (service, _) = Create();
        var result = service.Enroll("a");

        Assert.Equal("Enrolled", result.Code);
        Assert.Equal(1, service.GetSnapshot().EnrolledCount);
        Assert.Equal(1, service.GetSnapshot().AvailableSeats);
    }

    [Fact]
    public void Adds_eligible_learner_to_waitlist_when_full()
    {
        var (service, _) = Create();
        service.Enroll("a");
        service.Enroll("b");

        var result = service.Enroll("c");

        Assert.Equal("Waitlisted", result.Code);
        Assert.Equal(new[] { "c" }, service.GetSnapshot().WaitlistedLearners);
        Assert.Equal(2, service.GetSnapshot().EnrolledCount);
    }

    [Fact]
    public void Duplicate_enrollment_does_not_create_duplicate_records()
    {
        var (service, _) = Create();
        service.Enroll("a");
        service.Enroll("b");
        service.Enroll("c");

        Assert.Equal("Duplicate", service.Enroll("C").Code);
        var snapshot = service.GetSnapshot();
        Assert.Equal(2, snapshot.EnrolledCount);
        Assert.Single(snapshot.WaitlistedLearners);
    }

    [Fact]
    public void Drop_promotes_earliest_eligible_waitlisted_learner_fifo()
    {
        var (service, _) = Create();
        service.Enroll("a");
        service.Enroll("b");
        service.Enroll("c");
        service.Enroll("d");

        var result = service.Drop("a");

        Assert.Equal("Dropped", result.Code);
        Assert.Equal("c", result.PromotedLearnerId);
        Assert.Equal(new[] { "b", "c" }, service.GetSnapshot().EnrolledLearners);
        Assert.Equal(new[] { "d" }, service.GetSnapshot().WaitlistedLearners);
    }

    [Fact]
    public void Prerequisite_failure_does_not_change_state()
    {
        var (service, _) = Create();

        var result = service.Enroll("not-eligible");

        Assert.Equal("PrerequisiteFailed", result.Code);
        Assert.Empty(service.GetSnapshot().EnrolledLearners);
        Assert.Empty(service.GetSnapshot().WaitlistedLearners);
    }

    [Fact]
    public void Ineligible_front_entry_is_skipped_and_retained()
    {
        var (service, rules) = Create();
        service.Enroll("a");
        service.Enroll("b");
        service.Enroll("c"); // initially eligible and first in queue
        service.Enroll("d"); // second in queue
        rules.Remove("c");  // eligibility changes before the seat opens

        var result = service.Drop("a");
        var snapshot = service.GetSnapshot();

        Assert.Equal("d", result.PromotedLearnerId);
        Assert.Equal(new[] { "c" }, snapshot.WaitlistedLearners);
        Assert.Contains("d", snapshot.EnrolledLearners);
    }

    [Fact]
    public void Invalid_and_repeated_drops_do_not_corrupt_state()
    {
        var (service, _) = Create();
        service.Enroll("a");
        service.Enroll("b");
        var before = service.GetSnapshot();

        Assert.Equal("InvalidRequest", service.Drop(" ").Code);
        Assert.Equal("NotEnrolled", service.Drop("missing").Code);
        Assert.Equal("Dropped", service.Drop("a").Code);
        Assert.Equal("NotEnrolled", service.Drop("a").Code);

        var after = service.GetSnapshot();
        Assert.Equal(before.Capacity, after.Capacity);
        Assert.Equal(1, after.EnrolledCount);
        Assert.Equal(1, after.AvailableSeats);
    }

    [Fact]
    public async Task Concurrent_enrollment_never_exceeds_capacity_or_duplicates()
    {
        var store = new InMemoryCourseStore(capacity: 3);
        var rules = new MutablePrerequisites(
            Enumerable.Range(1, 30).Select(i => $"learner-{i}").ToArray());
        var service = new EnrollmentService(store, rules);
        var tasks = Enumerable.Range(1, 30)
            .Select(i => Task.Run(() => service.Enroll($"learner-{i}")));

        await Task.WhenAll(tasks);

        var snapshot = service.GetSnapshot();
        Assert.Equal(3, snapshot.EnrolledCount);
        Assert.Equal(27, snapshot.WaitlistedLearners.Count);
        Assert.Equal(30, snapshot.EnrolledLearners
            .Concat(snapshot.WaitlistedLearners).Distinct(StringComparer.OrdinalIgnoreCase).Count());
        Assert.Equal(0, snapshot.AvailableSeats);
    }

    private sealed class MutablePrerequisites(params string[] ids) : IPrerequisiteChecker
    {
        private readonly HashSet<string> _ids = new(ids, StringComparer.OrdinalIgnoreCase);
        public bool IsEligible(string learnerId) => _ids.Contains(learnerId);
        public void Remove(string learnerId) => _ids.Remove(learnerId);
    }

}
